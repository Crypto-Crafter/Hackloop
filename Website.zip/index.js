window.addEventListener('load', async () => {
    if (window.ethereum) {
        window.web3 = new Web3(window.ethereum);
        await window.ethereum.enable();
    } else {
        alert("No Ethereum provider detected. Install MetaMask!");
    }

    const accounts = await web3.eth.getAccounts();
    const userAddress = accounts[0];
    const userBalance = await getTokenBalance(userAddress);

    document.getElementById('userAddress').innerText = userAddress;
    document.getElementById('userBalance').innerText = userBalance;

    // Add more logic for initializing the app...
});

async function getTokenBalance(address) {
    const tokenAddress = 'CONTRACT_ADDRESS_OF_FRACTIONAL_SHARE_TOKEN';
    const contract = new web3.eth.Contract(FractionalShareTokenABI, tokenAddress);
    const balance = await contract.methods.balanceOf(address).call();
    return web3.utils.fromWei(balance, 'ether');
}

async function invest() {
    const amount = document.getElementById('investmentAmount').value;
    const platformAddress = 'CONTRACT_ADDRESS_OF_MICRO_INVESTING_PLATFORM';
    const platformContract = new web3.eth.Contract(MicroInvestingPlatformABI, platformAddress);

    // Send transaction to invest
    await platformContract.methods.invest(web3.utils.toWei(amount, 'ether')).send({ from: web3.eth.defaultAccount });

    // Update user balance
    const updatedBalance = await getTokenBalance(web3.eth.defaultAccount);
    document.getElementById('userBalance').innerText = updatedBalance;
}

async function withdraw() {
    const amount = document.getElementById('withdrawalAmount').value;
    const platformAddress = 'CONTRACT_ADDRESS_OF_MICRO_INVESTING_PLATFORM';
    const platformContract = new web3.eth.Contract(MicroInvestingPlatformABI, platformAddress);

    // Send transaction to withdraw
    await platformContract.methods.withdraw(web3.utils.toWei(amount, 'ether')).send({ from: web3.eth.defaultAccount });

    // Update user balance
    const updatedBalance = await getTokenBalance(web3.eth.defaultAccount);
    document.getElementById('userBalance').innerText = updatedBalance;
}